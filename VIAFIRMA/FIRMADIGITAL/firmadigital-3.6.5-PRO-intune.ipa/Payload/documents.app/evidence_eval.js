function evidenceValueIs(id, value) {
    for (var j = 0; j < data.evidences.length; j++) {
        var evidence = data.evidences[j];

        if (evidence.id == id && evidence.value == value) {
            return true;
        }
    }

    return false;
};

function evidenceValueIsTrue(id) {
    return evidenceValueIs(id, "true");
}

function evidenceValueIsFalse(id) {
    return evidenceValueIs(id, "false");
}

function evidenceIsEmpty(id) {
    for (var j = 0; j < data.evidences.length; j++) {
        var evidence = data.evidences[j];

        if (evidence.id == id && (evidence.value == null || evidence.value == "")) {
            return true;
        }
    }

    return false;
}

function evidenceIsNotEmpty(id) {
    return !evidenceIsEmpty(id);
}

function formItemIs(key, value) {
    for (var j = 0; j < data.items.length; j++) {
        var item = data.items[j];

        if (item.key == key && item.value == value) {
            return true;
        }
    }

    return false;
}



function formItemIsNot(key, value) {
  return !formItemIs(key, value);
}

function formItemIsEmpty(key) {
  for (var j = 0; j < data.items.length; j++) {
    var item = data.items[j];

    if (item.key === key && (!item.value || item.value === "")) {
      return true;
    }
  }

  return false;
}

function formItemIsNotEmpty(key) {
  return !formItemIsEmpty(key);
}

function includes(array, value) {
    for (var j = 0; j < array.length; j++) {
        var item = array[j];

        if (item == value) {
            return true;
        }
    }

    return false;
}

function execute(code) {
    var validMethods = ["evidenceValueIsTrue", "evidenceValueIsFalse", "evidenceIsEmpty", "evidenceIsNotEmpty", "formItemIs", "formItemIsNot", "formItemIsEmpty", "formItemIsNotEmpty"];
    var functions = code.match(/([a-zA-Z_{1}][a-zA-Z0-9_]+)(?=\()/g);
    var hasFunctions = /(function )([a-zA-Z_{1}][a-zA-Z0-9_]+)(?=\()/g.test(code);

    if (hasFunctions) {
        return null;
    }

    for (var i = 0; i < functions.length; i++) {
        var func = functions[i];

        if (!includes(validMethods, func)) {
            return null;
        }
    }

    return eval(code);
}
