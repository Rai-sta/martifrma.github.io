/* eslint-disable */
/* v1.0.32 */
var jfb;

(function () {
  // --------------------------------------------------------------------------
  // PRIVATE METHODS
  // --------------------------------------------------------------------------
  function JSONfind(obj, key, value) {
    var me = this;
    if (obj[key] == value) return obj[key];

    for (all in obj) {
      if (obj[all] != null && obj[all][key] == value) {
        return obj[all];
      }

      if (typeof obj[all] == "object" && obj[all] != null) {
        var found = JSONfind(obj[all], key, value);
        if (found) return found;
      }
    }
  }

  function randomNumber() {
    return (
      new Date().getTime() + "" + (Math.floor(Math.random() * 9000) + 1000)
    );
  }

  function DateFmt(fstr, months, days) {
    this.formatString = fstr;

    var mthNames =
      !months || months.length == 0
        ? [
          "Enero",
          "Febrero",
          "Marzo",
          "Abril",
          "Mayo",
          "Junio",
          "Julio",
          "Agosto",
          "Septiembre",
          "Octubre",
          "Noviembre",
          "Diciembre"
        ]
        : months;
    var dayNames =
      !days || days.length == 0
        ? [
          "Domingo",
          "Lunes",
          "Martes",
          "Miércoles",
          "Jueves",
          "Viernes",
          "Sábado"
        ]
        : days;
    var zeroPad = function (number) {
      return ("0" + number).substr(-2, 2);
    };

    var dateMarkers = {
      d: [
        "getDate",
        function (v) {
          return zeroPad(v);
        }
      ],
      m: [
        "getMonth",
        function (v) {
          return zeroPad(v + 1);
        }
      ],
      n: [
        "getMonth",
        function (v) {
          return mthNames[v];
        }
      ],
      w: [
        "getDay",
        function (v) {
          return dayNames[v];
        }
      ],
      y: ["getFullYear"],
      H: [
        "getHours",
        function (v) {
          return zeroPad(v);
        }
      ],
      M: [
        "getMinutes",
        function (v) {
          return zeroPad(v);
        }
      ],
      S: [
        "getSeconds",
        function (v) {
          return zeroPad(v);
        }
      ],
      i: ["toISOString"]
    };

    this.format = function (date) {
      var dateTxt = this.formatString.replace(/%(.)/g, function (m, p) {
        var rv = date[dateMarkers[p][0]]();

        if (dateMarkers[p][1] != null) {
          rv = dateMarkers[p][1](rv);
        }

        return rv;
      });

      return dateTxt;
    };
  }

  function getFormDefinition(cb) {
    if (
      typeof cb != "function" ||
      typeof json === "undefined" ||
      json == null
    ) {
      return;
    }

    jfb.data = json;

    cb(json);
  }

  function appendFormTitle(formDefinition) {
    if (formDefinition.title) {
      var $h1 = $("<h1>");

      $h1.addClass("jfb-form-title");
      $h1.text(formDefinition.title);

      jfb.$wrapper.append($h1);
    }
  }

  function createForm(formDefinition) {
    if (typeof formDefinition.containers == "undefined") {
      return;
    }
    $.each(formDefinition.containers, function (index, container) {
      appendContainer(container);
    });
  }

  function appendContainer(container) {
    var $container = $("<div>").addClass("jfb-container");
    var $containerTitle = $("<h2>");

    if (typeof container.rows == "undefined") {
      return;
    }

    $containerTitle.addClass("jfb-container-title");
    $containerTitle.text(container.title);

    if (container.title && container.title != "") {
      $container.append($containerTitle);
    }

    $.each(container.rows, function (index, row) {
      var $row = getRow(row);
      $container.append($row);
    });

    jfb.$wrapper.append($container);
  }

  function getRow(row) {
    var $row = $("<div>").addClass("jfb-row");

    if (typeof row.items == "undefined") {
      return $row;
    }

    $.each(row.items, function (index, item) {
      var $item = getItemObject(item);

      $row.append($item);

      if (item.hidden) {
        $item.hide();
      }
    });

    return $row;
  }

  function getItemObject(item) {
    var $item;
    var textfieldMatch = item.type.match(
      /^(text|password|date|datetime|time|email|number|tel|scan)$/
    );

    switch (true) {
      case textfieldMatch && textfieldMatch.length > 0:
        $item = getTextField(item);
        break;

      case item.type == "select":
        $item = getSelectFieldFor(item);
        break;

      case item.type == "textarea":
        $item = getTextareaFieldFor(item);
        break;

      case item.type == "checkbox":
        $item = getCheckboxFieldFor(item);
        break;

      case item.type == "radio":
        $item = getRadioFieldFor(item);
        break;

      case item.type == "todayText":
        $item = getTodayTextFieldFor(item);
        break;

      case item.type == "label":
        $item = getLabelFieldFor(item);
        break;

      case item.type == "link":
        $item = getLinkFieldFor(item);
        break;
    }

    return $item;
  }

  function getLabelFieldFor(item) {
    var $wrapper = getWrapperFor(item);

    var $item = $("<div>").text(item.value);

    var $pre = $("<pre>");

    $item.addClass("jfb-item");
    $item.addClass("jfb-item-label");
    $item.attr("id", getItemId(item));

    $pre.append($item);

    $wrapper.find("label").remove();
    $wrapper.append($pre);

    return $wrapper;
  }

  function getTodayTextFieldFor(item) {
    var $wrapper = getWrapperFor(item);
    var fmt = new DateFmt(
      item.format || "%d/%m/%y",
      item.monthNames,
      item.dayNames
    );
    var date = new Date();

    if (item.increment) {
      date.setDate(date.getDate() + item.increment);
    }

    var $item = $("<div>").text(fmt.format(date));

    setTimeout(function () {
      if (item.update && item.update.indexOf(",") != -1) {
        update = update.split(",");

        for (var i = 0, l = update.length; i < l; i++) {
          handleNestedItem($item.text(), update[i].trim());
        }
      } else {
        handleNestedItem($item.text(), item.update);
      }
    }, 1);

    $item.addClass("jfb-item");
    $item.attr("id", getItemId(item));

    $wrapper.append($item);

    return $wrapper;
  }

  function getLinkFieldFor(item) {
    var $wrapper = getWrapperFor(item);
    var $item = $("<a>")
      .text(item.text)
      .attr("target", "_blank")
      .attr("href", item.href);

    $item.addClass("jfb-item");
    $item.attr("id", getItemId(item));

    $wrapper.append($item);

    return $wrapper;
  }

  function getSelectFieldFor(item) {
    var $wrapper = getWrapperFor(item);
    var $item = $("<select />");
    var values = getItemValues(item);

    $item.addClass("jfb-item");
    $item.attr("id", getItemId(item));

    $.each(values, function (index, val) {
      $item.append($("<option />").text(val));
    });

    if (item.update) {
      handleNestedItems($item, item);
    }

    handleDisabled($item, item);

    $wrapper.append($item);

    if (item.value) {
      $item.val(item.value);

      setTimeout(function () {
        $item.val(item.value);

        $item.trigger("change");

        if (typeof $.fn.chosen != "undefined") {
          $item.trigger("chosen:updated");
        }
      }, 1);
    }

    return $wrapper;
  }

  function handleNestedItems($item, itemData) {
    $item.on("change", function () {
      updateNestedItems($item, itemData);
    });
  }

  function updateNestedItems($item, itemData) {
    var selectedValue = $item.val();
    var update = itemData.update;

    if (update.indexOf(",") != -1) {
      update = update.split(",");

      for (var i = 0, l = update.length; i < l; i++) {
        handleNestedItem(selectedValue, update[i].trim());
      }
    } else {
      handleNestedItem(selectedValue, update);
    }
  }

  function handleNestedItem(selectedValue, update) {
    var targetItem = JSONfind(jfb.data, "key", update);
    var $targetItem = $("#jfb-item-" + update);

    if ($targetItem.length <= 0) {
      return;
    }

    var values = getItemValues(targetItem, selectedValue);

    fillSelectItem($targetItem, values);

    $targetItem.trigger("change");
    $targetItem.trigger("chosen:updated");
  }

  function fillSelectItem($targetItem, data) {
    clearSelectItem($targetItem);

    $.each(data, function (i, val) {
      $targetItem.append($("<option />").text(val));
    });
  }

  function clearSelectItem($select) {
    $select.find("option").remove();
  }

  function getCheckboxFieldFor(item) {
    var $wrapper = getWrapperFor(item);
    var id = getItemId(item);

    $wrapper.attr("id", id);

    appendItemValues($wrapper, item);

    return $wrapper;
  }

  function getRadioFieldFor(item) {
    var $wrapper = getWrapperFor(item);
    var id = getItemId(item);

    $wrapper.attr("id", id);

    appendItemValues($wrapper, item);

    return $wrapper;
  }

  function getTextField(item) {
    var type = item.type;

    var $wrapper = getWrapperFor(item);
    var $item = $(
      '<input type="' +
      (type == "scan" ? "text" : type) +
      '" autocomplete="new-password" />'
    );
    var $button = $(
      '<button class="item-scan-button" id="' +
      item.key +
      '"><i class="fa fa-camera" /></button>'
    );

    $button.bind("click", function (e) {
      e.preventDefault();
      $(".jfb-scan-submit").click();
    });

    $item.addClass("jfb-item");
    $item.attr("id", getItemId(item));
    $item.attr("placeholder", getItemPlaceHolder(item));

    if (item.type == "text" && item.random) {
      $item.val(randomNumber());
    } else {
      $item.attr("value", getItemValue(item));
    }

    if (item.validationRegex) {
      $item.addClass("with-regex");
    }

    if (type == "tel") {
      $item.data("defaultCountry", item.defaultCountry);
      $item.data("preferredCountries", item.preferredCountries);
    }

    if (type == "datetime") {
      $item.prop("type", "datetime-local");
    }

    if (
      (type == "date" || type == "datetime" || type == "time") &&
      item.originalValue
    ) {
      $item.val(item.originalValue);
    }

    handleDisabled($item, item);

    $wrapper.append($item);
    if (item.type == "scan") {
      $wrapper.append($button);
    }

    return $wrapper;
  }

  function getTextareaFieldFor(item) {
    var $wrapper = getWrapperFor(item);
    var $item = $("<textarea />");

    $item.addClass("jfb-item");
    $item.attr("id", getItemId(item));
    $item.attr("placeholder", getItemPlaceHolder(item));
    $item.css("height", getItemHeight(item));
    $item.val(item.value);

    handleDisabled($item, item);

    $wrapper.append($item);

    return $wrapper;
  }

  function getWrapperFor(item) {
    var $wrapper = $("<p>").addClass(
      "jfb-item-wrapper jfb-item-type-" + item.type
    );

    $wrapper.attr("data-jfb-id", item.key);
    $wrapper.css("width", getItemWidth(item));

    if (item.label && item.label != "") {
      $wrapper.append(getItemLabel(item));
    }

    return $wrapper;
  }

  function getItemLabel(item) {
    if (item.type == "checkbox" || item.type == "radio") {
      var $label = $("<span>");

      $label.addClass("label").text(item.label);

      return $label;
    }

    var $label = $("<label>");

    $label.attr("for", getItemId(item));
    $label.text(item.label);

    if (item.required) {
      $label.append('<span class="required"> (*)</span>');
    }

    return $label;
  }

  function getItemValues(item, parentValue) {
    var values;

    if (!item) {
      return;
    }

    if (typeof item.list != "undefined" && item.list != "") {
      var t = $.grep(jfb.data.values, function (v) {
        return v.key === item.list;
      })[0];

      if (t) {
        values = t.values;
      }
    }

    // Deprecated on 1.0.9
    if (typeof item.refValues != "undefined" && item.refValues != "") {
      var t = $.grep(jfb.data.values, function (v) {
        return v.key === item.refValues;
      })[0];

      if (t) {
        values = t.values;
      }
    }

    if (typeof item.nestedList != "undefined" && item.nestedList != "") {
      var t = $.grep(jfb.data.nestedValues, function (v) {
        return v.key === item.nestedList;
      })[0];

      if (t) {
        values = t.values;
      }
    }

    if (typeof item.values != "undefined" && item.values != "") {
      if (typeof item.values == "object") {
        values = item.values;
      } else {
        values = item.values.split(",");
      }
    }

    if (parentValue) {
      temp = $.grep(values, function (v) {
        return v.key === parentValue;
      })[0];

      if (temp) {
        values = temp.values;
      }
    } else {
      if (typeof values == "undefined" || values.length == 0) {
        return [];
      }
      if (typeof values[0] == "object") {
        values = $.grep(values, function (v) {
          return v.key === values[0].key;
        })[0].values;
      }
    }

    return values;
  }

  function appendItemValues($wrapper, item) {
    var itemType = item.type;
    var values = getItemValues(item);
    var id = getItemId(item);

    $.each(values, function (index, val) {
      var $item_wrapper = $("<span>").addClass(
        "jfb-item-" + itemType + "-wrapper"
      );
      var $label = $("<label>");
      var $item = $('<input type="' + itemType + '" />');
      var item_id = id + "_" + index;

      $label.attr("for", item_id);
      $label.text(val);

      $item.addClass("jfb-item");
      $item.attr("name", id);
      $item.attr("id", item_id);
      $item.val(val);

      if (item.value == val) {
        $item.attr("checked", "checked");
        $item.attr("selected", "selected");
      }

      if (itemType == "checkbox") {
        if (item.value) {
          var checkboxValues = item.value.split("|");

          $.each(checkboxValues, function (i, v) {
            if (val == v.trim()) {
              $item.attr("checked", "checked");
            }
          });
        }
      }

      handleDisabled($item, item);

      $item_wrapper.append($item);
      $item_wrapper.append($label);
      $wrapper.append($item_wrapper);
    });
  }

  function getItemWidth(item) {
    return item.size + "%" || "auto";
  }

  function getItemId(item) {
    return "jfb-item-" + item.key;
  }

  function getItemPlaceHolder(item) {
    return item.placeHolder || "";
  }

  function getItemValue(item) {
    return item.value || "";
  }

  function getItemHeight(item) {
    return (item.height || 100) + "px";
  }

  function handleDisabled($item, item) {
    if (item.disabled) {
      $item.attr("disabled", "disabled");
    }
  }

  function handleItemData($wrapper, validation) {
    var $errorMessage = $wrapper.find("span.jfb-error-message");
    var itemId = $wrapper.data("jfb-id");
    var obj = JSONfind(jfb.data, "key", itemId);
    var error = false;
    var errorMessage;

    // GET VALUE
    // ---------

    // Default
    obj["value"] = $wrapper.find(".jfb-item").val();
    obj["originalValue"] = obj.value;

    // input type: tel
    if (obj.type == "tel" && !obj.validationRegex) {
      if (window.intlTelInputGlobals) {
    	  	obj.value = window.intlTelInputGlobals
          .getInstance($wrapper.find("input")[0])
          .getNumber();
      } else {
    	  	obj.value = $wrapper.find("input").intlTelInput("getNumber")
      }
    		
    }

    // Input type: checkbox
    if (obj.type == "checkbox") {
      obj.value = "";

      $wrapper.find(".jfb-item:checked").each(function (index, item) {
        if (index > 0) {
          obj.value += " | ";
        }

        obj.value += $(item).val();
      });
    }

    // Item type: link
    if (obj.type == "link") {
      obj.value = obj.text;
    }

    // Input type: radio
    if (obj.type == "radio") {
      obj.value = $wrapper.find(".jfb-item:checked").val() || "";
    }

    // Today text
    if (obj.type == "todayText") {
      obj.value = $wrapper.find(".jfb-item").text();
    }

    if (obj.type == "label") {
      obj.value = $wrapper.find(".jfb-item").text();
    }

    // Date
    if (obj.type == "date") {
      obj.value = $wrapper.find(".jfb-item").val();
      if (obj.value != "") {
        var date = new Date(obj.value + "T12:00:00");
        var fmt = new DateFmt(
          obj.format || "%d/%m/%y",
          obj.monthNames,
          obj.dayNames
        );
        obj.value = fmt.format(date);
      }
    }

    // Datetime
    if (obj.type == "datetime") {
      obj.value = $wrapper.find(".jfb-item").val();
      if (obj.value != "") {
        var date = new Date(obj.value);
        var fmt = new DateFmt(
          obj.format || "%d/%m/%y %H:%M",
          obj.monthNames,
          obj.dayNames
        );
        obj.value = fmt.format(date);
      }
    }

    if (typeof validation != "undefined" && !validation) {
      return false;
    }

    // VALIDATIONS
    // -----------

    // Validation: required
    if (obj.required) {
      if (!obj.value || obj.value == "") {
        errorMessage = "El campo es obligatorio";
      }
    }

    if (obj.match) {
      var $target = $("#jfb-item-" + obj.match);
      var $label = $target.closest(".jfb-item-wrapper").find("label");
      if (obj.value != $target.val()) {
        errorMessage =
          "Debe tener el mismo valor que el campo '" + $label.text() + "'";
      }
    }

    // Min length
    if (obj.minLength && obj.value.length > 0) {
      if (obj.value.length < obj.minLength) {
        errorMessage =
          "Debe contener al menos " + obj.minLength + " caracteres";
      }
    }

    if (obj.type == "number") {
      if (!$wrapper.find(".jfb-item").get(0).validity.valid) {
        errorMessage = "No es un valor válido";
      }
    }

    if (obj.type == "tel" && obj.value && obj.value != "" && !obj.validationRegex) {
      if (window.intlTelInputGlobals && 
        !window.intlTelInputGlobals
          .getInstance($wrapper.find(".jfb-item")[0])
          .isValidNumber()
      ) {
        errorMessage = "Número de teléfono incorrecto";
      }
    }

    // Max length
    if (obj.maxLength) {
      if (obj.value.length > obj.maxLength) {
        errorMessage =
          "Debe contener como máximo  " + obj.maxLength + " caracteres";
      }
    }

    var regex = /./;

    // Validation: custom
    if (obj.validation) {
      switch (obj.validation) {
        case "email":
          regex = /^[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%'*+\/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i;

          if (obj.value && !regex.test(obj.value)) {
            errorMessage = "Debe contener un email válido";
          }

          break;

        case "dni_es":
          if (obj.value && !isValidDNI(obj.value)) {
            errorMessage = "Debe contener un DNI válido";
          }
          break;

        case "dni_nie_es":
          if (obj.value && !isValidDNINIE(obj.value)) {
            errorMessage = "Debe contener un DNI/NIE válido";
          }
          break;

        case "cif_es":
          if (obj.value && !isValidCIF(obj.value)) {
            errorMessage = "Debe contener un CIF válido";
          }
          break;

        case "nif_cif_es":
          if (obj.value && !isValidCIF(obj.value) && !isValidDNI(obj.value)) {
            errorMessage = "Debe contener un NIF/CIF válido";
          }
          break;
      }
    }

    // Validation: regex
    if (obj.validationRegex) {
      regex = new RegExp(obj.validationRegex);

      if (obj.value && !regex.test(obj.value)) {
        errorMessage = "Debe contener un valor válido";
      }
    }

    // HANDLE ERRORS
    // -------------
    if (errorMessage && !obj.hidden) {
      error = true;

      $wrapper.addClass("jfb-error");

      if ($errorMessage.length <= 0) {
        $wrapper.append(
          '<span class="jfb-error-message">' + errorMessage + "</span>"
        );
      } else {
        $errorMessage.text(errorMessage);
      }
    } else {
      $wrapper
        .removeClass("jfb-error")
        .find("span.jfb-error-message")
        .remove();

      $wrapper.find(".jfb-error-message").removeClass("jfb-error-message");
    }

    if (jfb && jfb.data && jfb.data.settings && jfb.data.settings.validation) {
		
      error = !eval(jfb.data.settings.validation);

      if (error) {
        jfb.$wrapper.prepend(
          "<span class='jfb-global-error-message'>Alguna de las validaciones personalizadas del formulario no se cumplen</span>"
        );
      } else {
        jfb.$wrapper.find(".jfb-global-error-message").remove();
      }
    }

    return error;
  }

  function errorsPresent(context) {
    return (
      context.$wrapper.find(".jfb-error").length > 0 ||
      context.$wrapper.find(".jfb-global-error-message").length > 0
    );
  }

  function blurFocusedElement(context) {
    context.$wrapper.find(":focus").blur();
  }

  function isValidDNI(dni) {
    var numero;
    var letr;
    var letra;
    var expresion_regular_dni;

    expresion_regular_dni = /^\d{8}[a-zA-Z]$/;

    if (expresion_regular_dni.test(dni) == true) {
      numero = dni.substr(0, dni.length - 1);
      letr = dni.substr(dni.length - 1, 1);
      numero = numero % 23;
      letra = "TRWAGMYFPDXBNJZSQVHLCKET";
      letra = letra.substring(numero, numero + 1);
      if (letra != letr.toUpperCase()) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  }

  function isValidDNINIE(dni) {
    var numero, letr, letra;
    var expresion_regular_dni = /^[XYZ]?\d{5,8}[A-Z]$/;

    dni = dni.toUpperCase();

    if (expresion_regular_dni.test(dni) === true) {
      numero = dni.substr(0, dni.length - 1);
      numero = numero.replace("X", 0);
      numero = numero.replace("Y", 1);
      numero = numero.replace("Z", 2);
      letr = dni.substr(dni.length - 1, 1);
      numero = numero % 23;
      letra = "TRWAGMYFPDXBNJZSQVHLCKET";
      letra = letra.substring(numero, numero + 1);
      if (letra != letr) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  }

  function isValidCIF(cif) {
    //Quitamos el primer caracter y el ultimo digito
    var valueCif = cif.substr(1, cif.length - 2);

    var suma = 0;

    //Sumamos las cifras pares de la cadena
    for (i = 1; i < valueCif.length; i = i + 2) {
      suma = suma + parseInt(valueCif.substr(i, 1));
    }

    var suma2 = 0;

    //Sumamos las cifras impares de la cadena
    for (i = 0; i < valueCif.length; i = i + 2) {
      result = parseInt(valueCif.substr(i, 1)) * 2;
      if (String(result).length == 1) {
        // Un solo caracter
        suma2 = suma2 + parseInt(result);
      } else {
        // Dos caracteres. Los sumamos...
        suma2 = suma2 + parseInt(String(result).substr(0, 1)) + parseInt(String(result).substr(1, 1));
      }
    }

    // Sumamos las dos sumas que hemos realizado
    suma = suma + suma2;

    var unidad = String(suma).substr(1, 1)
    unidad = 10 - parseInt(unidad);

    var primerCaracter = cif.substr(0, 1).toUpperCase();

    if (primerCaracter.match(/^[FJKNPQRSUVW]$/)) {
      //Empieza por .... Comparamos la ultima letra
      if (String.fromCharCode(64 + unidad).toUpperCase() == cif.substr(cif.length - 1, 1).toUpperCase())
        return true;
    } else if (primerCaracter.match(/^[XYZ]$/)) {
      //Se valida como un dni
      var newcif;
      if (primerCaracter == "X")
        newcif = cif.substr(1);
      else if (primerCaracter == "Y")
        newcif = "1" + cif.substr(1);
      else if (primerCaracter == "Z")
        newcif = "2" + cif.substr(1);
      return isValidDNI(newcif);
    } else if (primerCaracter.match(/^[ABCDEFGHLM]$/)) {
      //Se revisa que el ultimo valor coincida con el calculo
      if (unidad == 10)
        unidad = 0;
      if (cif.substr(cif.length - 1, 1) == String(unidad))
        return true;
    } else {
      //Se valida como un dni
      return false;
    }
    return false;
  }

  // --------------------------------------------------------------------------
  // PUBLIC API
  // --------------------------------------------------------------------------
  jfb = {
    init: function (definition) {
      var context = this;

      if (typeof definition == "undefined") {
        getFormDefinition(function (definition) {
          jfb.data = definition;
          context.$wrapper = $(".jfb-form");
          appendFormTitle(definition);
          createForm(definition);
        });
      } else {
        jfb.data = definition;
        context.$wrapper = $(".jfb-form");
        appendFormTitle(definition);
        createForm(definition);
      }
    },

    getStringifiedData: function () {
      var context = this;

      context.$wrapper.find(".jfb-item-wrapper").each(function (index, item) {
        handleItemData($(item));
      });

      if (errorsPresent(context)) {
        return "error";
      }

      blurFocusedElement(context);

      return JSON.stringify(context.data);
    },

    getStringifiedDataWithoutValidation: function () {
      var context = this;
      context.$wrapper.find(".jfb-item-wrapper").each(function (index, item) {
        handleItemData($(item), false);
      });

      return JSON.stringify(context.data);
    },

    getItem: function (key) {
      return this.$wrapper.find("#jfb-item-" + key);
    },

	getItemObj: function (itemId) {
		var objId = itemId.split("jfb-item-");
		return JSONfind(jfb.data, "key", objId[1]);
	},

    startPhones: function (intlTelInput, utilsPath) {
      $(function () {
        $("input[type='tel']:not(.with-regex)").each(function () {
          var $el = $(this);
          var preferredCountries = ["es", "gb", "us", "pt"];

          if ($el.data("preferredCountries")) {
            preferredCountries = $el.data("preferredCountries").split(",");
          }

          var initialCountry = "es";

          if ($el.data("defaultCountry")) {
            if ($el.data("defaultCountry").indexOf(",") > -1) {
              initialCountry = $el.data("defaultCountry").split(",")[0];
            } else {
              initialCountry = $el.data("defaultCountry");
            }
          }

          var iti = intlTelInput($el[0], {
            utilsScript: utilsPath,
            nationalMode: true,
            preferredCountries: preferredCountries,
            initialCountry: initialCountry
          });

          $el.on("open:countrydropdown", function () {
            var $country = $el.closest(".iti").find(".iti__country-list");
            if (
              $country.offset().left + $country.outerWidth() >
              $(window).width()
            ) {
              $country.css(
                "left",
                -$country.closest(".intl-tel-input").outerWidth()
              );
            }
          });

          $el.on("close:countrydropdown", function () {
            var $country = $el.closest(".intl-tel-input").find(".country-list");
            $country.css("left", "0");
          });

          $el.blur(function () {
            if ($(this).val() != "" && $.trim($(this).val())) {
              if (iti.isValidNumber()) {
                iti.setNumber($(this).val());
                $(this).removeClass("jfb-error-message");
                $(this)
                  .closest(".intl-tel-input")
                  .siblings(".jfb-error-message")
                  .remove();
              } else {
                $(this).addClass("jfb-error-message");
                $(this)
                  .closest(".intl-tel-input")
                  .siblings(".jfb-error-message")
                  .remove();
                var $error = $("<span />")
                  .addClass("jfb-error-message")
                  .text("Teléfono no válido");
                $(this)
                  .closest(".intl-tel-input")
                  .after($error);
              }
            } else {
              $(this).removeClass("jfb-error-message");
              $(this)
                .closest(".intl-tel-input")
                .siblings(".jfb-error-message")
                .remove();
            }
          });
        });
      });
    }
  };

  // --------------------------------------------------------------------------
  // INIT
  // --------------------------------------------------------------------------
  if (typeof jQuery != "undefined" && typeof window.json != "undefined") {
    jQuery(function ($) {
      jfb.init();
    });
  }
})();
