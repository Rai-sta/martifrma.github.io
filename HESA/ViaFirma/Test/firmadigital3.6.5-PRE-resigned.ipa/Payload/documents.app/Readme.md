Guía para crear nuevos targets
==============================

Pasos para crear un nuevo target en Documents iOS:

1. Crear en el proyecto, bajo la carpeta "Targets", una nueva carpeta con el identificador del target que queremos crear ( ej: tigosign)
2. Irse al member center de Apple, para la cuenta InHouse, y en la pestaña "App Ids" crear la nueva aplicación.
>* Name: Nombre para identificar a la aplicación en la lista del propio member center. (ej: Tigo Sign )
>* Bundle ID: Identificador de la aplicación. Debe coincidir con lo que esté definido en los Config-pre.h o Config-pro.h descrito más abajo.
>* App Services : Lo que se indique aquí debe coincidir con lo que se especifique en el fichero entitlements.plist descrito más abajo.
>* APS (Apple Push Services), Data Protection, etc.
3. Generar el provisioning profile InHouse (se usará más abajo) desde el propio member center. En la pestaña "Provisioning Profile" creamos uno nuevo de tipo "In House". En el combo de App Id seleccionamos la app creada en el punto anterior. Generamos el provisioning y lo descargamos.
4. Dentro de la carpeta "Targets/tigosign" deberá estar lo siguiente:
>* Colors-tigosign.h : Contiene la información con los colores, tamaños y fuentes de la aplicación.
>* Config-pre.h : Contiene el nombre de la aplicación, la url, etc. Aquí hay que prestar especial cuidado a:
>>* CONSUMER_KEY : Debe coincidir con lo que esté definido en el backend de documents (bajo la pestaña Panel de control -> Aplicaciones)
>>* CONSUMER_SECRET : Debe coincidir con lo que esté definido en el backend de documents.
>>* BUNDLE_ID : Este valor será el identificador de la aplicación. es importante para pasos posteriores en la configuración en el member center de Apple y no debe confundirse con la CONSUMER_KEY, que es común para iOS y Android.
>* Config-pro.h : Mismo fichero pero con los valores de producción.
>* images.xcassets : Contendrá las imagenes del proyecto ajustadas a el nuevo target.
>* TSMessagesDesign.json : Json con diseño de las alertas de la aplicación. Se puede dejar el por defecto.
>* InHouse.mobileprovisioning : El provisioning profile generado en el punto 3. Le ponemos este nombre y lo copiamos en el propio target.
>* entitlements.plist / app.entitlements : Fichero que usará Xcode para compilar el ipa. Deberá contener:
	>>* application_identifier : El código de identificación de la aplicación tal y como está en el member center. Incluyendo el identificador del team (ej: CK6LUN7S9Z.com.viafirma.documents.ios.tigosign).
	>>* aps-environment : Si hemos configurado servicio de push , aquí deberá venir indicado (production, development, ...)
	>>* Data protection : Si lo hemos configurado, aquí deberá venir indicado también con el mismo valor.

Asegurarse de que los elementos de la carpeta NO tienen marcado el check de "Target membership" para ningún target en el File Inspector de Xcode. De hacerlo podrían darse conflictos entre los distintos ficheros de los distintos targets que comparten el mismo nombre.

5. Crear nuevo schema en Xcode. En la parte superior "Manage schemes...". Duplicamos un schema ya existente y le ponemos el nombre del target (ej: tigosign-pre, tigosign-pro, ...). Ahora en las opciones del target, deberemos asegurarnos que en la opción "Build -> Pre-actions" se está invocando al script con el nombre correcto del target (ej : $PROJECT_DIR/scheme-config.sh "$PROJECT_DIR" "tigosign-pro"). Con esta configuración podremos ejecutar localmente el target seleccionado, además de tenerlo todo configurado para la integración contínua.

6. Añadir el target en el combo de jenkins. En jenkins, configuración, habrá una larga lista de targets que son los que aparecen en el combo. Habría que añadir el nuevo target con el entorno correspondiente para que aparezcan en la combo y se ejecute el script completo. (ej: tigosign-pre , tigosign-pro).

7. Puede ser necesario añadir el Bundle ID y el nombre del provisioning profile, en el fichero "exportOptions.plist".

